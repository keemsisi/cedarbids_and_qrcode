var express = require('express') ; 
var http = require('http'); 
var fs = require('fs') ; 
var bodyParser = require('body-parser');
var path = require('path');
var qr = require('qr-image');
var hasher = require('object-hash');
var Emit

var staticURL = "http://192.168.1.25:4040";
var qr_svg = qr.image('lasisi akeem adeshina gifted11 lasisis is a good programmer', { type: 'png' });
var guestshash = new Set([]) ; // stores the guests ;

 
//var svg_string = qr.imageSync('I love QR!', { type: 'svg' });

var mysql_connector = require('mysql');
var databaseURL = "192.168.1.25";

var connection = mysql_connector.createPool(
    {
    "connectionLimit": 10 ,
    "user" : "cedarviewbidder@192.168.1.25",
    "password" : "cedarview_mysql",
    "database" : "cedarqrcode",
    "host": databaseURL,
    "port": 3306
});

console.log("[+] The connection to the MySQL cedarqrcode database was successful!");




var app = express() ; 


app.set('ttile', "Cedarbids | Web Platform for Contractors");
app.use(bodyParser.urlencoded({ extended: true , limit:50000000000, parameterLimit:1000000000000000000}));


var httpServer = http.createServer(app) ; 

app.get('/', (request ,response , error)=>{
    response.send("guranted") ;
});


//working
app.get("/generate/qrcode/new/all", (request ,response , error)=>{

    var imageQrCodeDir = __dirname+"/guest-qrcode-images/";
    var qr_png ; 
    var createdImageQrCode ; 
    var dateCreated = new Date();
    var guests = JSON.parse(request.query.data) ; 
    console.log(guests.length)
    
        guests.forEach(element => {
            dateCreated = new Date() ;
            console.log(dateCreated) ;
            var firstname   =  element.firstname;
            var lastname    =  element.lastname ;
            var phonenumber =  element.phonenumber;

            var filename = firstname+"-"+lastname+"-"+phonenumber;
            
            guestEncodedURL = `${staticURL}/guest/qrcode/authenticate/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
            writeImageQrCode(guestEncodedURL ,filename) ; 

            //hash value of each of the guest
            var guestHashed = hasher(guestEncodedURL) ;
                // console.log("yes!",guestHashed,guestHashed,guestHashed);
                
                if(!guestshash.has(guestHashed)){
                    guestshash.add(guestHashed); ///saving all the hash values
                    //INSERTING INTO THE DATABASE 
                connection.query("INSERT INTO cedarqrcode.RegisteredGuest() VALUES(UUID(),?,?,?,?,?,?,?,?) ",[guestHashed,dateCreated,null,null,false, firstname,lastname,phonenumber],function(error, fields,results){
                if(error){
                    console.log("ERROR :" ,error);
                    //response.write(error+"\n");
                    return ; //exist the function
                }else{
                    console.log(filename+"Guest added successfully to the database!");
                   // response.write({'message':"Successfully added new"+filename});
                }
            });
         }
        }
      );
        console.log(guestshash);
        response.send("New QrCodes Generated for the new guest..."+"\nStatus => Sucessful (OK!)") ;
});


//in progress 
app.get("/guest/qrcode/authenticate", function(request, response , error){

    
    var firstname = request.query.firstname ;
    var lastname = request.query.lastname ;
    var phonenumber = request.query.phonenumber ;

    var guestURL =`${staticURL}/guest/qrcode/authenticate/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
    var guestHashcode = hasher(guestURL) ; 

    // var nh = hasher(`http://192.168.1.25:4040/guest/qrcode/authenticate/?firstname=asdsdsd&lastname=dasdsdsd&phonenumber=asdsdsd`)


    console.log(hasher(guestURL));
    console.log(hasher(guestURL) == "9d7a07198171f8aa80a31219447cf4c047ce7bf4");


    console.log(guestURL);

    connection.query("SELECT guest_is_logedin FROM RegisteredGuest WHERE hashcode = ?",["9d7a07198171f8aa80a31219447cf4c047ce7bf4"], (error, fields, results)=>{
        var message = "" ;
       
        var condition = false; // default condition before authentication 

        if(error){
            console.error("Error Occured in the database", JSON.parse(error).Error) ;
            response.send(`<h1
            style= 'margin-top: 2% ;text-align: center ;color:red; border: 5px solid red ; padding: 30px ;'>
            [ Server Error ] - Qr Code Checking/Out was not successful <br/> Contact the system administrator</h1>`);
        }
        else{
            //if this is true then guest does not exist
            //working dont touch
            if( typeof fields[0] === 'undefined'){
                message = `<div style = 'border : 2px solid red; border-radius : 10px ;'>
                <h1 style='color : green; paddind: 10px ;'> Message :=:=: Sorry Guest <br/> 
                Firstname : ${firstname} <br/> Lastname : ${lastname} <br/> Phone Number : ${phonenumber}<br/>
                <strong style='color : red'>IS NOT REGISTERED</strong>
                </h1>
                <div>`;
                console.log(fields);
                condition = true ;
                response.send(message);
           }else{

                message = fields[0].guest_is_logedin === 0 ?
                `<div style='background-color : green; border-radius : 30px;height:100px  ;'> 
                <h1 style='color : white'> Message :=:=: Guest <strong>CHECKED IN</strong> was succesful </h1> <div>` :
                `<div style='background-color : green ;text-align:center; border-radius : 30px ; height:100px'> 
                <h1 style='color : white; text-align: center'> Message :=:=: Guest <strong>CHECKED OUT</strong> was succesful </h1> <div>` ;

                connection.query("UPDATE RegisteredGuest SET guest_is_logedin = NOT guest_is_logedin WHERE hashcode = ? ",[guestHashcode], (error, fields, results)=>{
                    if(error){
                           console.error(error) ;
                           response.send(`
                           <h1
                            style= 'margin-top: 2% ;text-align: center ;color:red; border: 5px solid red ; padding: 30px ;'>
                            [ Server Error ] - Qr Code Checking/Out was not successful <br/> Contact the system administrator
                           </h1>`);
        
                       }
                       else{
                           console.log("Operation was perform on ",guestURL);
                           response.send(message);
                       }
                   }); 
           }
        }
    });
});


app.get("/test" ,(request, response ,error)=>{
    connection.query("SELECT * FROM RegisteredGuest limit 5", (error, fields, results)=>{
        response.send(fields) ;
    });
})

//working
function writeImageQrCode(dataToEncode,filename, dirToWriteQrCodes){
    var qr_png = qr.image(dataToEncode, { type: 'png' });
    //creates a write stream file
    qr_png.pipe(fs.createWriteStream(dirToWriteQrCodes+filename+".png"));
    console.log("done writing image!", filename);
}


function generateGuestQrCodeFromDatabase(){
    var newImageDir = path.join(__dirname,"/new-guest-qrcode-image"+new Date());

    if(fs.existsSync(newImageDir)){
        fs.mkDirSync(newImageDir);
    }
    connection.query("SELECT firstname , lastname, phonenumber FROM cedarqrcode",(error, fields, results)=>{

        if(error){
            console.log("ERROR", error);
        }else{
            
             fields.forEach(guest=>{
            var firstname   = guest.firstname ;
            var lastname    = guest.lastname ;
            var phonenumber = guest.phonenumber ;

            var filename = firstname+"-"+lastname+"-"+phonenumber;
            var guestQrCode = `${staticURL}/guest/qrcode/authenticate/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
            writeImageQrCode(guestQrCode ,filename, newImageDir);
        });

        console.log("DONE WRITING IMAGES");
    } 
    });
}

httpServer.listen(4040 , ()=>{
    console.log("The server is running"); 
});
