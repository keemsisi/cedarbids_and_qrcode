/**
 * This is the default port the server listens to when it is running
 */
var port = 4040 ;
var hostname = "http://192.168.1.25";
var serverURL = hostname+":"+port;
var confirmCheckPathname = "/guest/confirm/check";


