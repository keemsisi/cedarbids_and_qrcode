var excelToJSONConverter = require('convert-excel-to-json');

const result = excelToJSONConverter({
    sourceFile: 'guest_excel.xlsx'
});

console.log(result)

