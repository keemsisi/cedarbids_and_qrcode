var express = require('express') ; 
var http = require('http'); 
var fs = require('fs') ; 
var bodyParser = require('body-parser');
var path = require('path');
var qr = require('qr-image');
var hasher = require('object-hash');
var uuid_generator = require('uuid/v1');
var requestJS = require('request') ;
var archiver = require('archiver');
var excelToJSON = require('excel-as-json');
var multer = require('multer');
var archiver = require('archiver');
var EventEmitter = require('events');

var serverMessage = new EventEmitter();
var errorMessages = [] ;
var successMessage = [] ;


/**
 * Create the server event handler
 */

 /**
  * push the error message t
  */
 serverMessage.on('error',(error)=>{
    errorMessages.push(error);
 });

 /**
  * Push the success message to the  success message buffer
  */
 serverMessage.on('success',(success)=>{
     successMessage.push(success) ;
 })

var counterArray = [] ;
var masterDirFolder = path.join(__dirname , "/guest-qrcode-images");

var months = ["JANUARY","FEBUARY","MATCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER"] ;

var allQrImageDirectory = months[new Date().getMonth()]+"-"+months[new Date().getFullYear()];


for( let i = 200  ; i <= 4000 ; i+=200){
    counterArray.push(i);
}

var staticURL = "http://192.168.1.36:4040";
//var staticURL = "http://192.168.1.36:"+process.env.PORT || 4040;

var qr_svg = qr.image('lasisi akeem adeshina gifted11 lasisis is a good programmer', { type: 'png' });
var guestshash = new Set([]) ; // stores tthe guests ;
var successSetBuffer = new Set([]);
var errorSetBuffer = new Set([]) ;
var guestEncodedURL = "";
// global.imam = "I AM FROM GLOBAL VARIABLE SCOPE";

 
//var svg_string = qr.imageSync('I love QR!', { type: 'svg' });

var mysql_connector = require('mysql');
////var databaseURL = "192.168.1.36";

const { Pool ,  Client } = require('pg');
const pool = new Pool() ; // connection pool ;

const client = new Client({
    user: 'postgres',
    host: 'localhost',
    database: 'cedarqrcode',
    password: 'postgres',
    port: 5432,
});

console.log("Message connection" ,client.connect()) ;
console.log("[+] The connection to the PSQL cedarqrcode database was successful!");

var app = express() ; 

//var public = path.join(); // home director

app.set('ttile', "Latter Rain Assembly Guest QR");
app.use(express.static(path.join(__dirname)));
app.use(bodyParser.urlencoded({ extended: true , limit:50000000000, parameterLimit:1000000000000000000}));


var httpServer = http.createServer(app) ; 

app.get('/', (request ,response , error)=>{
    response.send("guranted") ;
});


//working
app.get("/generate/qrcode/new/all", (request ,response , error)=>{

    var dateCreated = request.query.date ;




    /**
     * imageQrCodeDir This is the directory that the qr image will all be 
     */
    var imageQrCodeDir = masterDirFolder+"/"+allQrImageDirectory + "/" + dateCreated;
    var qr_png ; 
    var createdImageQrCode ; 
    var dateCreated = new Date();

    var guests = JSON.parse(request.query.data) ; //the data in the JSON file sent to the server

    console.log(guests.length); 
        guests.forEach(element => {



            errorSetBuffer.add("<br/>");
            successSetBuffer.add("<br/>");
          

            dateCreated = new Date() ;
            var firstname   =  element.firstname;
            var lastname    =  element.lastname ;
            var phonenumber =  element.phonenumber;
            var marital_status = element.maritalStatus;
            var home_address = element.homeAddress ;
            var gender = element.gender;
            var age = element.age ;

            var filename = firstname+"-"+lastname+"-"+phonenumber;
            
           guestEncodedURL = `${staticURL}/guest/qrcode/authenticate/stage/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
           console.log(guestEncodedURL);


            //hash value of each of the guest
            var guestHashed = hasher(guestEncodedURL);
                // console.log("yes!",guestHashed,guestHashed,guestHashed);
                
                if(!guestshash.has(guestHashed)){
                    guestshash.add(guestHashed); ///saving all the hash values
                    //INSERTING INTO THE DATABASE   
                writeImageQrCode(guestEncodedURL,filename, imageQrCodeDir) ; 

                client.query("INSERT INTO RegisteredGuest(id,hashcode,datecreated,last_checked_in ,last_checked_out,checked_in,firstname,lastname,phonenumber,marital_status,home_address,gender,age) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) ",[
                    uuid_generator(),guestHashed,dateCreated,null,null,false,
                    firstname,lastname,phonenumber,marital_status,home_address,gender,age],
                    
                    function(error, fields,results){
                if(error){
                       errorSetBuffer.add("Could't create Guest:" + filename);
                       console.error("Guest ",filename, "was not created!");
                }else{
                    console.log(filename+"\nGuest added successfully to the database!");
                    successSetBuffer.add("Guest " +filename+" created successfully") //store all the successfully created qr code for guest
                    console.log("Successfully Created :" , filename );
                }
            });
         }
        }
      );
    
      var success = "" ;
      var error = "" ;

      var errorIter = errorSetBuffer.values() ;
      var successIter = successSetBuffer.values();

      successSetBuffer.forEach(suc=>{
        success += successIter.next().value + "<br/>"
      })

      errorSetBuffer.forEach(err=>{
        error +=errorIter.next().value +"<br/>";
      });

  
      console.log("ERROR:",error,errorSetBuffer)
      console.log("SUCCESS:",success, successSetBuffer);
      console.log(guestshash);


      response.json({"error":error ,"success":success}) ; // send all the messages at onces and the fromt the client end the messages will be extractred 
      successSetBuffer = new Set([]);
      errorSetBuffer = new Set([]);

});



//in progress 
app.get("/guest/qrcode/authenticate", function(request, response , error){
    
    var firstname = request.query.firstname ;
    var lastname = request.query.lastname ;
    var phonenumber = request.query.phonenumber ;

    var guestURL =`${staticURL}/guest/qrcode/authenticate/stage/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
    var guestHashcode = hasher(guestURL) ; 

    // var nh = hasher(`http://192.168.1.36:4040/guest/qrcode/authenticate/?firstname=asdsdsd&lastname=dasdsdsd&phonenumber=asdsdsd`)


    console.log(hasher("http://192.168.1.36:4040/guest/qrcode/authenticate/?firstname=Lasisi&lastname=Akeem&phonenumber=08032571534"));
    console.log("CONDITION CASE",hasher(guestURL) === "a93c5884105bda5906ba8c1ee67aee4c5efe7390");


    client.query("SELECT firstname,lastname,phonenumber,checked_in FROM registeredguest WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber],(error, fields)=>{
        var message = "" ;
       
        var condition = false; // default condition before authentication 

        if(error){
            console.error("Error Occured in the database", JSON.parse(error).Error) ;
            response.send(`<h1
            style= 'margin-top: 2% ;text-align: center ;color:red; border: 5px solid red ; padding: 30px ;'>
            [ Server Error ] - Qr Code Checking/Out was not successful <br/> Contact the system administrator</h1>`);
        }
        else{
            //if this is true then guest does not exist
            //working dont touch
            console.log("RESULTS=====>",fields)
            if( typeof fields['rows'][0] === 'undefined'){
                message = `<div style = 'border : 2px solid red; border-radius : 10px ;'>
                <h1 style='color : green; paddind: 10px ;'> Message :=:=: Sorry Guest <br/> 
                Firstname : ${firstname} <br/> Lastname : ${lastname} <br/> Phone Number : ${phonenumber}<br/>
                <strong style='color : red'>IS NOT REGISTERED</strong>
                </h1>
                <div>`;
                console.log(fields);
                condition = true ;
                response.send(message);
           }else{

                message = fields['rows'][0].checked_in === true ?
               /**
                 * This is an html template that will be sent to the user browser agent 
                 * when the guest is successfully checked out
                 */
                `<div style='background-color : white ;text-align:center; 
                border-radius : 10px ; height:200px; border-top:10px solid yellow; 
                border:3px solid orange;border-bottom-right-radius:100px;
                border-bottom-left-radius:100px'> 
                        <div>
                            <h5>Firstname: ${fields['rows'][0].firstname} <br/> Lastname: ${fields['rows'][0].lastname} <br/> Phone Number: ${fields['rows'][0].phonenumber} </h5>
                        </div>
                        <h1 style='color : green; text-align: center'> Message :- Guest <strong>CHECKED OUT</strong> was successful </h1> 
                <div>` :
                /**
                 * This is an html template that will be sent to the user browser agent 
                 * when the guest is successfully checked in
                 */
                `<div style='background-color : white ;text-align:center; 
                border-radius : 10px ; height:200px; border-top:2px solid green; 
                border:3px solid green;border-bottom-right-radius:100px;
                border-bottom-left-radius:100px'>
                    <div>
                        <h5>Firstname: ${fields['rows'][0].firstname} <br/> Lastname: ${fields['rows'][0].lastname} <br/> Phone Number: ${fields['rows'][0].phonenumber} </h5>
                    </div>
                    <h1 style='color : green;text-align: center'> Message :- Guest <strong>CHECKED IN</strong> was successful </h1> 
                <div>` ;

                /**
                 * SET THE LAST CHECKED IN AND OUT DATE AND TIME
                 * the true value means that the guest is checked in  and the date will be set for checked
                 * while false means the guest is checked out already and it set the date will be set for checked in
                 */
                if(fields['rows'][0].checked_in === true){
                    client.query("UPDATE RegisteredGuest SET last_checked_out = now() WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber], (error, fields)=>{
                        if(error){
                            console.log("Error", error);
                        }else{
                            console.log("LAST CHECKED IN SET FOR ",firstname,lastname,phonenumber);
                    }
                });
            }else{
                    client.query("UPDATE RegisteredGuest SET last_checked_in = now() WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber], (error, fields)=>{
                        if(error){
                            console.log("Error", error);
                        }else{
                            console.log("LAST CHECKED OUT SET FOR ",firstname,lastname,phonenumber);
                        }
                    });
                } //end else
                


                /**
                 * This is where the real logic occurs to check the guest out and in based on their current state in the postgres DB
                 */
                client.query("UPDATE RegisteredGuest SET checked_in = NOT checked_in WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber], (error, fields, results)=>{
                   
                   
                    if(error){
                           console.error(error) ;
                           response.send(`
                           <div style='border-radius: 10px; box-shadow: 3px 10px 10px #ddd; height: 400px; width: 700px'>
                                <h1 style= 'margin-top: 2% ;text-align: center ;color:red; border: 5px solid red ; padding: 30px ;'>
                                    [ Server Error ] - Qr Code Checking/Out was not successful <br/> Contact the system administrator
                                </h1>
                           </div>
                          `);
        
                       }
                       else{
                           console.log("Operation was perform on ",guestURL);
                           response.send(message);
                       }
                   }); 


           } // end the inner else
        } // end the outer most else
    });
});



//working
function writeImageQrCode(dataToEncode,filename, dirToWriteQrCodes){

    if(fs.existsSync(masterDirFolder) === true ){

    }

    var qr_png = qr.image(dataToEncode, { type: 'png' });

    //creates a write stream file
    qr_png.pipe(fs.createWriteStream(dirToWriteQrCodes+filename+".png"));

    console.log("done writing image!", filename);
}



/**
 * This function  will generate Qr code based on the data available in the database Engine
 */
function generateGuestQrCodeFromDatabase(){
    var newImageDir = path.join(__dirname,"/new-guest-qrcode-image"+new Date());

    if(fs.existsSync(newImageDir)){
        fs.mkDirSync(newImageDir);
    }
    connection.query("SELECT firstname , lastname, phonenumber FROM cedarqrcode",(error, fields)=>{

        if(error){
            console.log("ERROR", error);
        }else{
            
             fields.forEach(guest=>{
            var firstname   = guest.firstname ;
            var lastname    = guest.lastname ;
            var phonenumber = guest.phonenumber ;

            var filename = firstname+"-"+lastname+"-"+phonenumber;
            var guestQrCode = `${staticURL}/guest/qrcode/authenticate/stage?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
            writeImageQrCode(guestQrCode ,filename, newImageDir);
        });

        console.log("DONE WRITING IMAGES");
    } 
    });
}


app.get("/guest/qrcode/authenticate/stage", (request, response, error)=>{

    var firstname = request.query.firstname ;
    var lastname  = request.query.lastname ;
    var phonenumber = request.query.phonenumber ;


    var file = fs.createReadStream(path.join(__dirname,"/confirm_check.html"));
    /**
     * Send the confirmation page to the user
     */
    response.redirect(`http://192.168.1.36:4040/confirm_check.html?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`); 
});


app.get("/guest/checked/state", (request, response , error)=>{
    var firstname = request.query.firstname ;
    var lastname  = request.query.lastname ;
    var phonenumber = request.query.phonenumber ;

    var guestHashcode = hasher(`${staticURL}/guest/qrcode/authenticate/stage/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`);

    client.query("SELECT checked_in FROM registeredguest where hashcode = $1",[guestHashcode],(error, result)=>{
        if(error){
            console.log(Error , error);
            response.send("Status 500 : Server Error");
        }else{
            if(result.rows[0]){
                response.send(JSON.stringify({"checked_in":result.rows[0].checked_in})) ;
                console.log(result.rows[0])
                console.log("State was checked ",firstname,lastname,phonenumber);
            }else{
                response.send(`<div class="container" style = 'border : 2px solid red; border-radius : 10px ; margin: 0 auto ; display: flex ;'>
                <h1 style='color : green; paddind: 10px ;'> Message :=:=: Sorry Guest Authentication Failed <br/> 
                Firstname : ${firstname} <br/> Lastname : ${lastname} <br/> Phone Number : ${phonenumber}<br/>
                <strong style='color : red'>IS NOT REGISTERED</strong>
                </h1>
                <div>`)
            }
            
        }
    }); 
});


app.get("/guest/registeredguest/all/:limit/:offSet", (request , response , error)=>{
            var limit     = request.params.limit;
            var offSet    = request.params.offSet ; 

            client.query(`SELECT firstname , lastname ,datecreated, phonenumber ,last_checked_in, last_checked_out , checked_in,gender,age FROM registeredguest LIMIT ${limit}  OFFSET ${offSet}`,function(error, result){
                global.counter =99999999;
                 // al.push(counter);
            
             if(error){
                 console.log(error);
                 response.send("SERVER ERROR... Please Contact the server administrator");
             }else{
                 response.json(result.rows);
                 console.log("All guest was requested... response was successful");
             }
         });  
});

app.get("/guest/registeredguest/count/all", (request , response , error)=>{
        client.query(`select count(id) from registeredguest`,function(error, result){
        if(error){
            console.log(error);
            response.send("SERVER ERROR... Please Contact the server administrator");
        }else{
            response.json(result);
            console.log("All guest were counted... response was successful");
        }
    });
});


app.get("/guest/registeredguest/count/", (request , response , error)=>{
        var queryCount = request.query.argv ;
        console.log(queryCount);
        if(queryCount != undefined){
            client.query(`select count(checked_in) from registeredguest where checked_in=$1`,[queryCount],function(error, result){

                if(error){
                    console.log(error);
                    response.send("SERVER ERROR... Please Contact the server administrator");
                }else{
                    response.json(result);
                    console.log("Some Checked in guest were counted!");
                }
            });             
        }

});


app.get("/test" ,(request, response ,error)=>{

    client.query("SELECT * FROM RegisteredGuest limit 5", (error, fields)=>{
        response.send(fields) ;

    });
});


/**
 * Download all the generated Qr-Code image
 */
app.get("/guest/generated-qr-image/zipfile",(request,response,error)=>{

    var dateCreated = request.query.creationDate ; 
    var date = dateCreated.date ; 

    imageQrCodeDir = path.join(masterDirFolder , )

    //zip the image folder to




})



/**
 * 
 * @param {*} folderToZip  This is the folder directory to be zippped
 * @param {*} folderName   This is the name of the folder the server will sent to the client Agent to download
 */
function createGestQrimageZip(folderToZip , folderName ){
 
    // create a file to stream archive data to.
    var output = fs.createWriteStream(folderToZip + folderName );
    
    var archive = archiver('zip', {
      zlib: { level: 9 } // Sets the compression level.
    });
     
    // listen for all archive data to be written
    // 'close' event is fired only when a file descriptor is involved
    output.on('close', function() {
      console.log(archive.pointer() + ' total bytes');
      console.log('archiver has been finalized and the output file descriptor has closed.');
    });
    
    
    // good practice to catch this error explicitly
    archive.on('error', function(err) {
      throw err;
    });
     
    // pipe archive data to the file
    archive.pipe(output);
      
    // append files from a sub-directory, putting its contents at the root of archive
    archive.directory('subdir/', false);
    
     
    // finalize the archive (ie we are done appending files but streams have to finish yet)
    // 'close', 'end' or 'finish' may be fired right after calling this method so register to them beforehand
    // archive.finalize(); call the finalize when all the files has been writen to the zip folder
    
    /**returns the archiver and the output */
    return {output , archiver}
    
    }
    
    /**
     * Creates folder for each month
     * make sure the master directory is not deleted
     */
setInterval(()=>{
        if(fs.exists(masterDirFolder) === true){
            fs.mkdirSync(path.join(masterDirFolder , months[ new Date().getMonth] + "-"+ new Date().getFullYear()))
        }
},24 * 3600 * 30);



httpServer.listen(4040 , ()=>{
    console.log("[+] The server is running on ADDRESS : ","192.168.1.36"," and on a PORT :","4040"); 
});


