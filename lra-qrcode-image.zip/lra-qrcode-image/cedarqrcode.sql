DROP TABLE IF EXISTS RegisteredGuest ;
CREATE TABLE RegisteredGuest (
    id VARCHAR(36) NOT NULL PRIMARY KEY,
    hashcode VARCHAR(40) NOT NULL UNIQUE,
    datecreated TIMESTAMP , 
    last_checked_in TIMESTAMP ,
    last_checked_out TIMESTAMP,
    checked_in BOOLEAN,
    firstname VARCHAR(250) ,
    lastname VARCHAR(250),
    phonenumber VARCHAR(13)
);
