var express = require('express') ; 
var http = require('http'); 
var fs = require('fs') ; 
var bodyParser = require('body-parser');
var path = require('path');
var qr = require('qr-image');
var hasher = require('object-hash');
var uuid_generator = require('uuid/v1');
var requestJS = require('request') ;

var staticURL = "http://192.168.1.25:4040";
//var staticURL = "http://192.168.1.25:"+process.env.PORT || 4040;

var qr_svg = qr.image('lasisi akeem adeshina gifted11 lasisis is a good programmer', { type: 'png' });
var guestshash = new Set([]) ; // stores tthe guests ;

var guestEncodedURL = "";

 
//var svg_string = qr.imageSync('I love QR!', { type: 'svg' });

var mysql_connector = require('mysql');
////var databaseURL = "192.168.1.25";

const { Pool ,  Client } = require('pg');
const pool = new Pool() ; // connection pool ;

const client = new Client({
    user: 'postgres',
    host: '192.168.1.25',
    database: 'cedarqrcode',
    password: 'postgres',
    port: 5432,
});

console.log("Message connection" ,client.connect()) ;
console.log("[+] The connection to the PSQL cedarqrcode database was successful!");

var app = express() ; 

//var public = path.join(); // home director

app.set('ttile', "Latter Rain Assembly Guest QR");
app.use(express.static(path.join(__dirname)));
app.use(bodyParser.urlencoded({ extended: true , limit:50000000000, parameterLimit:1000000000000000000}));


var httpServer = http.createServer(app) ; 

app.get('/', (request ,response , error)=>{
    response.send("guranted") ;
});


//working
app.get("/generate/qrcode/new/all", (request ,response , error)=>{

    var imageQrCodeDir = __dirname+"/guest-qrcode-images/";
    var qr_png ; 
    var createdImageQrCode ; 
    var dateCreated = new Date();
    var guests = JSON.parse(request.query.data) ; 
    console.log(guests.length)
    
        guests.forEach(element => {
            dateCreated = new Date() ;
            var firstname   =  element.firstname;
            var lastname    =  element.lastname ;
            var phonenumber =  element.phonenumber;

            var filename = firstname+"-"+lastname+"-"+phonenumber;
            
           guestEncodedURL = `${staticURL}/guest/qrcode/authenticate/stage/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
           console.log(guestEncodedURL);

            writeImageQrCode(guestEncodedURL ,filename, imageQrCodeDir) ; 

            //hash value of each of the guest
            var guestHashed = hasher(guestEncodedURL);
                // console.log("yes!",guestHashed,guestHashed,guestHashed);
                
                if(!guestshash.has(guestHashed)){
                    guestshash.add(guestHashed); ///saving all the hash values
                    //INSERTING INTO THE DATABASE 
                client.query("INSERT INTO RegisteredGuest(id,hashcode,datecreated,last_checked_in ,last_checked_out,checked_in,firstname,lastname,phonenumber) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) ",[uuid_generator(),guestHashed,dateCreated,null,null,false, firstname,lastname,phonenumber],function(error, fields,results){
                if(error){
                    console.log("ERROR :" ,error);
                    //response.write(error+"\n");
                    return ; //exist the function
                }else{
                    console.log(filename+"\nGuest added successfully to the database!");
                   // response.write({'message':"Successfully added new"+filename});
                }
            });
         }
        }
      );
        response.send("New QrCodes Generated for the new guest..."+"\nStatus => Sucessful (OK!)") ;
});


//in progress 
app.get("/guest/qrcode/authenticate", function(request, response , error){
    
    var firstname = request.query.firstname ;
    var lastname = request.query.lastname ;
    var phonenumber = request.query.phonenumber ;

    var guestURL =`${staticURL}/guest/qrcode/authenticate/stage/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
    var guestHashcode = hasher(guestURL) ; 

    // var nh = hasher(`http://192.168.1.25:4040/guest/qrcode/authenticate/?firstname=asdsdsd&lastname=dasdsdsd&phonenumber=asdsdsd`)


    console.log(hasher("http://192.168.1.25:4040/guest/qrcode/authenticate/?firstname=Lasisi&lastname=Akeem&phonenumber=08032571534"));
    console.log("CONDITION CASE",hasher(guestURL) === "a93c5884105bda5906ba8c1ee67aee4c5efe7390");


    client.query("SELECT firstname,lastname,phonenumber,checked_in FROM registeredguest WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber],(error, fields)=>{
        var message = "" ;
       
        var condition = false; // default condition before authentication 

        if(error){
            console.error("Error Occured in the database", JSON.parse(error).Error) ;
            response.send(`<h1
            style= 'margin-top: 2% ;text-align: center ;color:red; border: 5px solid red ; padding: 30px ;'>
            [ Server Error ] - Qr Code Checking/Out was not successful <br/> Contact the system administrator</h1>`);
        }
        else{
            //if this is true then guest does not exist
            //working dont touch
            console.log("RESULTS=====>",fields)
            if( typeof fields['rows'][0] === 'undefined'){
                message = `<div style = 'border : 2px solid red; border-radius : 10px ;'>
                <h1 style='color : green; paddind: 10px ;'> Message :=:=: Sorry Guest <br/> 
                Firstname : ${firstname} <br/> Lastname : ${lastname} <br/> Phone Number : ${phonenumber}<br/>
                <strong style='color : red'>IS NOT REGISTERED</strong>
                </h1>
                <div>`;
                console.log(fields);
                condition = true ;
                response.send(message);
           }else{

                message = fields['rows'][0].checked_in === true ?
               /**
                 * This is an html template that will be sent to the user browser agent 
                 * when the guest is successfully checked out
                 */
                `<div style='background-color : white ;text-align:center; 
                border-radius : 10px ; height:300px; border-top:2px solid yellow; 
                border:3px solid orange;border-bottom-right-radius:100px;
                border-bottom-left-radius:100px'> 
                        <div>
                            <h5>Firstname: ${fields['rows'][0].firstname} <br/> Lastname: ${fields['rows'][0].lastname} <br/> Phone Number: ${fields['rows'][0].phonenumber} </h5>
                        </div>
                        <h1 style='color : green; text-align: center'> Message := Guest <strong>CHECKED OUT</strong> was successful </h1> 
                <div>` :

                /**
                 * This is an html template that will be sent to the user browser agent 
                 * when the guest is successfully checked in
                 */
                `<div style='background-color : white ;text-align:center; 
                border-radius : 10px ; height:300px; border-top:2px solid green; 
                border:3px solid green;border-bottom-right-radius:100px;
                border-bottom-left-radius:100px'>
                    <div>
                        <h5>Firstname: ${fields['rows'][0].firstname} <br/> Lastname: ${fields['rows'][0].lastname} <br/> Phone Number: ${fields['rows'][0].phonenumber} </h5>
                    </div>
                    <h1 style='color : green;text-align: center'> Message := Guest <strong>CHECKED IN</strong> was successful </h1> 
                <div>` ;

                /**
                 * SET THE LAST CHECKED IN AND OUT DATE AND TIME
                 * the true value means that the guest is checked in  and the date will be set for checked
                 * while false means the guest is checked out already and it set the date will be set for checked in
                 */
                if(fields['rows'][0].checked_in === true){
                    client.query("UPDATE RegisteredGuest SET last_checked_out = now() WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber], (error, fields)=>{
                        if(error){
                            console.log("Error", error);
                        }else{
                            console.log("LAST CHECKED IN SET FOR ",firstname,lastname,phonenumber);
                    }
                });
            }else{
                    client.query("UPDATE RegisteredGuest SET last_checked_in = now() WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber], (error, fields)=>{
                        if(error){
                            console.log("Error", error);
                        }else{
                            console.log("LAST CHECKED OUT SET FOR ",firstname,lastname,phonenumber);
                        }
                    });
                } //end else
                


                /**
                 * This is where the real logic occurs to check the guest out and in based on their current state in the postgres DB
                 */
                client.query("UPDATE RegisteredGuest SET checked_in = NOT checked_in WHERE firstname=$1 and lastname=$2 and phonenumber=$3",[firstname,lastname,phonenumber], (error, fields, results)=>{
                   
                   
                    if(error){
                           console.error(error) ;
                           response.send(`
                           <div style='border-radius: 10px; box-shadow: 3px 10px 10px #ddd; height: 400px; width: 700px'>
                                <h1 style= 'margin-top: 2% ;text-align: center ;color:red; border: 5px solid red ; padding: 30px ;'>
                                    [ Server Error ] - Qr Code Checking/Out was not successful <br/> Contact the system administrator
                                </h1>
                           </div>
                          `);
        
                       }
                       else{
                           console.log("Operation was perform on ",guestURL);
                           response.send(message);
                       }
                   }); 


           } // end the inner else
        } // end the outer most else
    });
});


app.get("/test" ,(request, response ,error)=>{

    client.query("SELECT * FROM RegisteredGuest limit 5", (error, fields)=>{
        response.send(fields) ;

    });
})

//working
function writeImageQrCode(dataToEncode,filename, dirToWriteQrCodes){

    var qr_png = qr.image(dataToEncode, { type: 'png' });

    //creates a write stream file
    qr_png.pipe(fs.createWriteStream(dirToWriteQrCodes+filename+".png"));

    console.log("done writing image!", filename);
}



/**
 * This function  will generate Qr code based on the data available in the database Engine
 */
function generateGuestQrCodeFromDatabase(){
    var newImageDir = path.join(__dirname,"/new-guest-qrcode-image"+new Date());

    if(fs.existsSync(newImageDir)){
        fs.mkDirSync(newImageDir);
    }
    connection.query("SELECT firstname , lastname, phonenumber FROM cedarqrcode",(error, fields)=>{

        if(error){
            console.log("ERROR", error);
        }else{
            
             fields.forEach(guest=>{
            var firstname   = guest.firstname ;
            var lastname    = guest.lastname ;
            var phonenumber = guest.phonenumber ;

            var filename = firstname+"-"+lastname+"-"+phonenumber;
            var guestQrCode = `${staticURL}/guest/qrcode/authenticate/stage?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`;
            writeImageQrCode(guestQrCode ,filename, newImageDir);
        });

        console.log("DONE WRITING IMAGES");
    } 
    });
}


app.get("/guest/qrcode/authenticate/stage", (request, response, error)=>{

    var firstname = request.query.firstname ;
    var lastname  = request.query.lastname ;
    var phonenumber = request.query.phonenumber ;


    var file = fs.createReadStream(path.join(__dirname,"/confirm_check.html"));
    /**
     * Send the confirmation page to the user
     */
    response.redirect(`http://192.168.1.25:4040/confirm_check.html?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`); 
});


app.get("/guest/checked/state", (request, response , error)=>{
    var firstname = request.query.firstname ;
    var lastname  = request.query.lastname ;
    var phonenumber = request.query.phonenumber ;

    var guestHashcode = hasher(`${staticURL}/guest/qrcode/authenticate/stage/?firstname=${firstname}&lastname=${lastname}&phonenumber=${phonenumber}`);

    client.query("SELECT checked_in FROM registeredguest where hashcode = $1",[guestHashcode],(error, result)=>{
        if(error){
            console.log(Error , error);
            response.send("Status 500 : Server Error");
        }else{
            response.send( {"checked_in":result.rows[0].checked_in}) ;
            console.log("State was checked ",firstname,lastname,phonenumber);
        }
    }); 
});

httpServer.listen(4040 , ()=>{
    console.log("The server is running"); 
});
