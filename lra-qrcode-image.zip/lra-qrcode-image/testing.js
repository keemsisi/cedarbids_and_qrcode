var checker = require('./server-variables') ;

// checker.addError("Error exit in the program you are running");
// console.log(checker.getAllErrors())
console.log(checker.getAllErrors())
console.log(checker.addError("I am an error value"));
console.log(checker.addError("I am an aerro2 value"));
console.log(checker.addError("I am an aerro3 value"));
console.log(checker.addError("I am an aerro4 value"));
console.log(checker.addError("I am an aerro5 value"));
console.log(checker.addError("I am an aerro6 value"));
console.log(checker.addSuccess("I am a success value"));

console.log(checker.getAllErrors())


console.log(checker.tester);